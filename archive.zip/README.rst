Byterun
-------

This is a pure-Python implementation of a Python bytecode execution virtual
machine.  I started it to get a better understanding of bytecodes so I could
fix branch coverage bugs in coverage.py.

